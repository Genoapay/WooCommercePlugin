=== WooCommerce Genoapay Gateway ===
Contributors: FutureLab
Tags: genoapay
Requires at least: 4.8.1
Tested up to: 4.8.3
Stable tag: 1.0.0
License: GPLv3 or later License
URI: http://www.gnu.org/licenses/gpl-3.0.html
WC requires at least: 3.1.1
WC tested up to: 3.2.3

A payment gateway for Genoapay